//
//  PokemonApp.swift
//  Pokemon
//
//  Created by iOSLab on 05/04/25.
//

import SwiftUI

@main
struct PokemonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
